# 📱 Social Analytics Flutter App

AI-Powered Social Media Analytics - YouTube, Reddit, Instagram, Twitter, Pinterest

## 🚀 Setup Kasa Karava

### 1. Backend URL Change Kara
`lib/services/api_service.dart` file madhye:
```dart
static const String baseUrl = 'http://10.0.2.2:8000'; // ← He tumchya URL ne change kara
```

| Situation | URL |
|-----------|-----|
| Android Emulator | `http://10.0.2.2:8000` |
| iOS Simulator | `http://localhost:8000` |
| Physical Device | `http://YOUR_PC_IP:8000` |
| Production | `https://your-api.com` |

### 2. Dependencies Install Kara
```bash
flutter pub get
```

### 3. App Run Kara
```bash
flutter run
```

---

## 📱 App Features

| Screen | Features |
|--------|----------|
| 🏠 Dashboard | Summary, Platform Stats, Trending, Recent Posts |
| 🔍 Search | YouTube, Reddit, Twitter, Pinterest search + Trending |
| 🤖 AI Chat | Session-based chatbot, platform context |
| ⚠️ Crisis | Text analyze kara, history pahija |
| 👥 CrewAI | 4-Agent pipeline run kara |

## 📁 File Structure
```
lib/
├── main.dart              # App entry + Navigation
├── theme.dart             # Colors, Theme
├── services/
│   └── api_service.dart   # Sagale API calls
├── screens/
│   ├── dashboard_screen.dart
│   ├── search_screen.dart
│   ├── chatbot_screen.dart
│   ├── crisis_screen.dart
│   └── crew_screen.dart
└── widgets/
    ├── stat_card.dart
    ├── post_card.dart
    └── loading_widget.dart
```

## 🔧 Android Permissions (AndroidManifest.xml)
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

## 📦 Packages Used
- `http` - API calls
- `provider` - State management  
- `fl_chart` - Charts
- `shimmer` - Loading effects
- `flutter_animate` - Animations
