import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/stat_card.dart';
import '../widgets/post_card.dart';
import '../widgets/error_widget.dart';
import '../widgets/loading_widget.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _api = ApiService();
  Map? _summary;
  List _trending = [];
  List _recentPosts = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        _api.getDashboardSummary(),
        _api.getDashboardTrending(limit: 5),
        _api.getRecentPosts(limit: 10),
      ]);
      setState(() {
        _summary = results[0] as Map?;
        _trending = results[1] as List;
        _recentPosts = results[2] as List;
        _loading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Social Analytics', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text('AI-Powered Insights', style: TextStyle(fontSize: 12, color: AppTheme.secondary)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
          ),
        ],
      ),
      body: _loading
          ? const AppLoadingWidget(message: 'Dashboard load hotoye...')
          : _error != null
              ? AppErrorWidget(message: _error!, onRetry: _loadData)
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildSummaryCards(),
                        const SizedBox(height: 24),
                        _buildPlatformStats(),
                        const SizedBox(height: 24),
                        _buildTrendingSection(),
                        const SizedBox(height: 24),
                        _buildRecentPosts(),
                      ],
                    ),
                  ),
                ),
    );
  }

  Widget _buildSummaryCards() {
    if (_summary == null) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Overview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.6,
          children: [
            StatCard(
              title: 'Total Posts',
              value: '${_summary?['total_posts'] ?? _summary?['posts'] ?? '--'}',
              icon: Icons.article,
              color: AppTheme.primary,
            ),
            StatCard(
              title: 'Platforms',
              value: '${_summary?['platforms'] ?? 5}',
              icon: Icons.devices,
              color: AppTheme.secondary,
            ),
            StatCard(
              title: 'Avg Sentiment',
              value: _formatSentiment(_summary?['avg_sentiment'] ?? _summary?['sentiment']),
              icon: Icons.sentiment_satisfied,
              color: Colors.orange,
            ),
            StatCard(
              title: 'Total Engagement',
              value: _formatNumber(_summary?['total_engagement'] ?? _summary?['engagement']),
              icon: Icons.trending_up,
              color: AppTheme.danger,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildPlatformStats() {
    final platforms = ['youtube', 'reddit', 'instagram', 'twitter', 'pinterest'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Platforms', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: platforms.map((p) {
              final color = AppTheme.platformColors[p] ?? AppTheme.primary;
              final icon = AppTheme.platformIcons[p] ?? Icons.public;
              return GestureDetector(
                onTap: () => _showPlatformDetails(p),
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      Icon(icon, color: color, size: 28),
                      const SizedBox(height: 6),
                      Text(p[0].toUpperCase() + p.substring(1),
                          style: TextStyle(color: color, fontSize: 12)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildTrendingSection() {
    if (_trending.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Trending Posts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: AppTheme.danger.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text('🔥 LIVE',
                  style: TextStyle(color: AppTheme.danger, fontSize: 11)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ..._trending.map((post) => PostCard(post: post as Map)).toList(),
      ],
    );
  }

  Widget _buildRecentPosts() {
    if (_recentPosts.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Recent Posts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ..._recentPosts.map((post) => PostCard(post: post as Map)).toList(),
      ],
    );
  }

  void _showPlatformDetails(String platform) async {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => _PlatformDetailSheet(platform: platform),
    );
  }

  String _formatSentiment(dynamic val) {
    if (val == null) return '--';
    if (val is num) return val.toStringAsFixed(2);
    return val.toString();
  }

  String _formatNumber(dynamic val) {
    if (val == null) return '--';
    final n = val is num ? val.toInt() : int.tryParse(val.toString()) ?? 0;
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

class _PlatformDetailSheet extends StatefulWidget {
  final String platform;
  const _PlatformDetailSheet({required this.platform});

  @override
  State<_PlatformDetailSheet> createState() => _PlatformDetailSheetState();
}

class _PlatformDetailSheetState extends State<_PlatformDetailSheet> {
  final _api = ApiService();
  Map? _data;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _api.getPlatformStats(widget.platform).then((d) {
      setState(() { _data = d; _loading = false; });
    }).catchError((e) {
      setState(() { _error = e.toString(); _loading = false; });
    });
  }

  @override
  Widget build(BuildContext context) {
    final color = AppTheme.platformColors[widget.platform] ?? AppTheme.primary;
    final icon = AppTheme.platformIcons[widget.platform] ?? Icons.public;
    final name = widget.platform[0].toUpperCase() + widget.platform.substring(1);

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(width: 12),
            Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 20),
          if (_loading) const Center(child: CircularProgressIndicator())
          else if (_error != null)
            Text('Error: $_error', style: TextStyle(color: AppTheme.danger))
          else if (_data != null)
            ..._data!.entries.map((e) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(e.key, style: const TextStyle(color: Colors.white60)),
                  Text('${e.value}', style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            )),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
