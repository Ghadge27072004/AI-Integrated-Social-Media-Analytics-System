import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme.dart';

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime time;
  ChatMessage({required this.text, required this.isUser, DateTime? time})
      : time = time ?? DateTime.now();
}

class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  State<ChatbotScreen> createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final _api = ApiService();
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _loading = false;
  String _sessionId = 'default';
  String _platform = 'general';

  final List<String> _platforms = [
    'general', 'youtube', 'reddit', 'instagram', 'twitter', 'pinterest'
  ];

  final List<String> _suggestions = [
    '📊 Dashboard summary sanga',
    '🔥 Konta trending ahe?',
    '📈 Sentiment analysis kar',
    '⚠️ Crisis check kar',
  ];

  @override
  void initState() {
    super.initState();
    _addBotMessage(
      '👋 Namaste! Mi tumcha Social Analytics AI assistant ahe. '
      'Tumhi platform trends, sentiment, ya crisis alerts baddal vicharoo shakta.',
    );
  }

  void _addBotMessage(String text) {
    setState(() {
      _messages.add(ChatMessage(text: text, isUser: false));
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty || _loading) return;
    _msgCtrl.clear();
    setState(() {
      _messages.add(ChatMessage(text: text, isUser: true));
      _loading = true;
    });
    _scrollToBottom();

    try {
      final res = await _api.chat(text,
          sessionId: _sessionId, platform: _platform);
      final reply = res['response'] ?? res['message'] ?? res['reply'] ?? '$res';
      _addBotMessage(reply.toString());
    } catch (e) {
      _addBotMessage('❌ Error: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _clearSession() async {
    try {
      await _api.clearChatSession(_sessionId);
      setState(() => _messages.clear());
      _addBotMessage('✅ Session clear zala. Navyane boluyat!');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Chatbot'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.tune),
            tooltip: 'Platform select kara',
            onSelected: (p) => setState(() => _platform = p),
            itemBuilder: (_) => _platforms
                .map((p) => PopupMenuItem(
                      value: p,
                      child: Row(children: [
                        if (_platform == p) const Icon(Icons.check, size: 16),
                        const SizedBox(width: 8),
                        Text(p[0].toUpperCase() + p.substring(1)),
                      ]),
                    ))
                .toList(),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: _clearSession,
            tooltip: 'Chat clear kara',
          ),
        ],
      ),
      body: Column(
        children: [
          _buildPlatformBadge(),
          Expanded(child: _buildMessageList()),
          if (_messages.length <= 1) _buildSuggestions(),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildPlatformBadge() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 6),
      color: AppTheme.surface,
      child: Center(
        child: Text(
          'Platform: ${_platform[0].toUpperCase()}${_platform.substring(1)}',
          style: TextStyle(color: AppTheme.secondary, fontSize: 12),
        ),
      ),
    );
  }

  Widget _buildMessageList() {
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.all(16),
      itemCount: _messages.length + (_loading ? 1 : 0),
      itemBuilder: (ctx, i) {
        if (i == _messages.length) return _buildTypingIndicator();
        return _buildMessageBubble(_messages[i]);
      },
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final isUser = msg.isUser;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: AppTheme.primary.withOpacity(0.2),
              child: const Icon(Icons.smart_toy, size: 16, color: AppTheme.primary),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isUser ? AppTheme.primary : AppTheme.card,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
              ),
              child: Text(msg.text, style: const TextStyle(fontSize: 14)),
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            const CircleAvatar(
              radius: 16,
              backgroundColor: AppTheme.secondary,
              child: Icon(Icons.person, size: 16, color: Colors.black),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Row(
      children: [
        CircleAvatar(
          radius: 16,
          backgroundColor: AppTheme.primary.withOpacity(0.2),
          child: const Icon(Icons.smart_toy, size: 16, color: AppTheme.primary),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.card,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: List.generate(3, (i) => _buildDot(i)),
          ),
        ),
      ],
    );
  }

  Widget _buildDot(int index) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + index * 200),
      builder: (ctx, val, child) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: AppTheme.primary.withOpacity(0.5 + val * 0.5),
          shape: BoxShape.circle,
        ),
      ),
    );
  }

  Widget _buildSuggestions() {
    return SizedBox(
      height: 44,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        children: _suggestions.map((s) => GestureDetector(
          onTap: () => _sendMessage(s.replaceAll(RegExp(r'[^\w\s]'), '').trim()),
          child: Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              border: Border.all(color: AppTheme.primary.withOpacity(0.4)),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(s, style: const TextStyle(fontSize: 12)),
          ),
        )).toList(),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 12,
        bottom: 12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: AppTheme.card,
        border: Border(top: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              onSubmitted: _sendMessage,
              maxLines: null,
              decoration: const InputDecoration(
                hintText: 'Message likha...',
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 10),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            child: ElevatedButton(
              onPressed: _loading ? null : () => _sendMessage(_msgCtrl.text),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(50, 50),
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _loading
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.send),
            ),
          ),
        ],
      ),
    );
  }
}
