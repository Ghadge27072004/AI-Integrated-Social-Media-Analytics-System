import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/loading_widget.dart';

class CrewScreen extends StatefulWidget {
  const CrewScreen({super.key});

  @override
  State<CrewScreen> createState() => _CrewScreenState();
}

class _CrewScreenState extends State<CrewScreen> {
  final _api = ApiService();
  final _textCtrl = TextEditingController();
  final _kwCtrl = TextEditingController();

  List _agents = [];
  Map? _pipelineResult;
  bool _running = false;
  bool _agentsLoading = true;
  String _platform = 'instagram';
  String? _error;

  final List<String> _platforms = [
    'instagram', 'youtube', 'reddit', 'twitter', 'pinterest'
  ];

  @override
  void initState() {
    super.initState();
    _loadAgents();
  }

  Future<void> _loadAgents() async {
    try {
      final res = await _api.listCrewAgents();
      setState(() { _agents = res; _agentsLoading = false; });
    } catch (e) {
      setState(() => _agentsLoading = false);
    }
  }

  Future<void> _runPipeline() async {
    if (_textCtrl.text.trim().isEmpty) return;
    setState(() { _running = true; _error = null; _pipelineResult = null; });
    try {
      final res = await _api.runCrewPipeline(
        _textCtrl.text.trim(),
        platform: _platform,
        keyword: _kwCtrl.text.trim().isEmpty ? null : _kwCtrl.text.trim(),
      );
      setState(() { _pipelineResult = res; _running = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _running = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Icon(Icons.groups, color: AppTheme.secondary),
          const SizedBox(width: 8),
          const Text('CrewAI Pipeline'),
        ]),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildAgentsSection(),
            const SizedBox(height: 20),
            _buildPipelineForm(),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.danger.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(_error!, style: TextStyle(color: AppTheme.danger)),
              ),
            ],
            if (_running) ...[
              const SizedBox(height: 20),
              const AppLoadingWidget(message: '4 AI agents kaam karat ahet...'),
            ],
            if (_pipelineResult != null) ...[
              const SizedBox(height: 20),
              _buildResult(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAgentsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('AI Agents', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (_agentsLoading)
          const Center(child: CircularProgressIndicator())
        else if (_agents.isEmpty)
          _buildDefaultAgents()
        else
          ..._agents.asMap().entries.map((e) => _buildAgentCard(e.value, e.key)),
      ],
    );
  }

  Widget _buildDefaultAgents() {
    final defaultAgents = [
      {'name': 'Sentiment Analyst', 'role': 'Text sentiment analyze karto', 'icon': Icons.sentiment_satisfied},
      {'name': 'Trend Detector', 'role': 'Trending topics detect karto', 'icon': Icons.trending_up},
      {'name': 'Crisis Monitor', 'role': 'Harmful content detect karto', 'icon': Icons.warning_amber},
      {'name': 'Report Generator', 'role': 'Final insights generate karto', 'icon': Icons.summarize},
    ];
    return Column(
      children: defaultAgents.asMap().entries
          .map((e) => _buildAgentCard(e.value, e.key))
          .toList(),
    );
  }

  Widget _buildAgentCard(dynamic agent, int index) {
    final colors = [AppTheme.primary, AppTheme.secondary, AppTheme.warning, Colors.purple];
    final color = colors[index % colors.length];
    final icons = [Icons.psychology, Icons.trending_up, Icons.shield, Icons.summarize];
    final icon = agent is Map && agent['icon'] != null
        ? agent['icon'] as IconData
        : icons[index % icons.length];

    final name = agent is Map ? (agent['name'] ?? agent['role'] ?? 'Agent ${index + 1}') : '$agent';
    final desc = agent is Map ? (agent['description'] ?? agent['role'] ?? '') : '';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: color, width: 3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$name', style: const TextStyle(fontWeight: FontWeight.bold)),
                if (desc.isNotEmpty)
                  Text('$desc', style: const TextStyle(color: Colors.white54, fontSize: 12)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text('Agent ${index + 1}',
                style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildPipelineForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Pipeline Run Kara', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _platform,
          decoration: const InputDecoration(labelText: 'Platform'),
          dropdownColor: AppTheme.card,
          items: _platforms.map((p) => DropdownMenuItem(
            value: p,
            child: Text(p[0].toUpperCase() + p.substring(1)),
          )).toList(),
          onChanged: (v) => setState(() => _platform = v!),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _kwCtrl,
          decoration: const InputDecoration(
            hintText: 'Keyword (optional)',
            prefixIcon: Icon(Icons.tag),
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _textCtrl,
          maxLines: 4,
          decoration: const InputDecoration(
            hintText: 'Post text yeta analyze karaycha ahe...',
            alignLabelWithHint: true,
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _running ? null : _runPipeline,
            icon: _running
                ? const SizedBox(
                    width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.play_arrow),
            label: Text(_running ? 'Pipeline running...' : '4-Agent Pipeline Start Kara'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.secondary,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildResult() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.secondary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.secondary.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.check_circle, color: AppTheme.secondary),
            const SizedBox(width: 8),
            const Text('Pipeline Complete!',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppTheme.secondary)),
          ]),
          const SizedBox(height: 12),
          const Divider(color: Colors.white12),
          const SizedBox(height: 8),
          ..._pipelineResult!.entries.map((e) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(e.key, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                const SizedBox(height: 4),
                Text('${e.value}',
                    style: const TextStyle(fontWeight: FontWeight.w500)),
                const Divider(color: Colors.white10, height: 16),
              ],
            ),
          )),
        ],
      ),
    );
  }
}
