import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/loading_widget.dart';

class CrisisScreen extends StatefulWidget {
  const CrisisScreen({super.key});

  @override
  State<CrisisScreen> createState() => _CrisisScreenState();
}

class _CrisisScreenState extends State<CrisisScreen>
    with SingleTickerProviderStateMixin {
  final _api = ApiService();
  final _textCtrl = TextEditingController();
  late TabController _tabCtrl;

  Map? _analysisResult;
  List _history = [];
  bool _analyzing = false;
  bool _historyLoading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _tabCtrl.addListener(() {
      if (_tabCtrl.index == 1 && _history.isEmpty) _loadHistory();
    });
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _analyze() async {
    if (_textCtrl.text.trim().isEmpty) return;
    setState(() { _analyzing = true; _error = null; _analysisResult = null; });
    try {
      final res = await _api.analyzeCrisis(_textCtrl.text.trim());
      setState(() { _analysisResult = res; _analyzing = false; });
    } catch (e) {
      setState(() { _error = e.toString(); _analyzing = false; });
    }
  }

  Future<void> _loadHistory() async {
    setState(() => _historyLoading = true);
    try {
      final res = await _api.getCrisisHistory();
      setState(() { _history = res; _historyLoading = false; });
    } catch (e) {
      setState(() { _historyLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Icon(Icons.warning_amber, color: AppTheme.warning, size: 22),
          const SizedBox(width: 8),
          const Text('Crisis Alert'),
        ]),
        bottom: TabBar(
          controller: _tabCtrl,
          tabs: const [
            Tab(text: 'Analyze'),
            Tab(text: 'History'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _buildAnalyzeTab(),
          _buildHistoryTab(),
        ],
      ),
    );
  }

  Widget _buildAnalyzeTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoBanner(),
          const SizedBox(height: 16),
          TextField(
            controller: _textCtrl,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: 'Post ya comment paste kara crisis check sathi...',
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _analyzing ? null : _analyze,
              icon: _analyzing
                  ? const SizedBox(
                      width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.search),
              label: Text(_analyzing ? 'Analyzing...' : 'Crisis Analyze Kara'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.danger,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.danger.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(_error!, style: TextStyle(color: AppTheme.danger)),
            ),
          ],
          if (_analysisResult != null) ...[
            const SizedBox(height: 20),
            _buildResult(),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.danger.withOpacity(0.2), AppTheme.warning.withOpacity(0.1)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.danger.withOpacity(0.3)),
      ),
      child: const Row(
        children: [
          Icon(Icons.shield, color: AppTheme.warning),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'AI crisis detection system — harmful, toxic, ya emergency content detect karto',
              style: TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResult() {
    final res = _analysisResult!;
    final level = res['crisis_level'] ?? res['level'] ?? 0;
    final isCrisis = (res['is_crisis'] ?? res['crisis'] ?? level > 1) == true;
    final color = isCrisis ? AppTheme.danger : AppTheme.secondary;
    final icon = isCrisis ? Icons.warning_amber : Icons.check_circle;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(width: 12),
            Text(
              isCrisis ? '⚠️ CRISIS DETECTED' : '✅ No Crisis Found',
              style: TextStyle(
                color: color, fontWeight: FontWeight.bold, fontSize: 16),
            ),
          ]),
          const SizedBox(height: 12),
          const Divider(color: Colors.white12),
          const SizedBox(height: 8),
          ...res.entries.map((e) {
            if (['is_crisis', 'crisis'].contains(e.key)) return const SizedBox.shrink();
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 140,
                    child: Text(e.key,
                        style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  ),
                  Expanded(
                    child: Text('${e.value}',
                        style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildHistoryTab() {
    if (_historyLoading) return const AppLoadingWidget(message: 'History load hotoye...');
    if (_history.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.history, size: 60, color: Colors.white24),
            const SizedBox(height: 12),
            const Text('Kahi history nahi', style: TextStyle(color: Colors.white38)),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _loadHistory, child: const Text('Refresh')),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _history.length,
      itemBuilder: (ctx, i) {
        final item = _history[i] as Map? ?? {};
        final isCrisis = item['is_crisis'] == true || (item['crisis_level'] ?? 0) > 1;
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: Icon(
              isCrisis ? Icons.warning_amber : Icons.check_circle,
              color: isCrisis ? AppTheme.danger : AppTheme.secondary,
            ),
            title: Text(
              '${item['text'] ?? item['content'] ?? 'Post'}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              'Level: ${item['crisis_level'] ?? item['level'] ?? '--'}',
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
            trailing: Text(
              isCrisis ? 'CRISIS' : 'SAFE',
              style: TextStyle(
                color: isCrisis ? AppTheme.danger : AppTheme.secondary,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        );
      },
    );
  }
}
