import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/post_card.dart';
import '../widgets/loading_widget.dart';
import '../widgets/error_widget.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with SingleTickerProviderStateMixin {
  final _api = ApiService();
  final _searchCtrl = TextEditingController();
  late TabController _tabCtrl;

  String _selectedPlatform = 'youtube';
  List _results = [];
  bool _loading = false;
  String? _error;
  bool _searched = false;

  final List<Map<String, dynamic>> _platforms = [
    {'key': 'youtube', 'label': 'YouTube', 'icon': Icons.play_circle_fill},
    {'key': 'reddit', 'label': 'Reddit', 'icon': Icons.reddit},
    {'key': 'twitter', 'label': 'Twitter', 'icon': Icons.tag},
    {'key': 'pinterest', 'label': 'Pinterest', 'icon': Icons.push_pin},
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    if (_searchCtrl.text.trim().isEmpty) return;
    setState(() { _loading = true; _error = null; _searched = true; });
    try {
      dynamic res;
      final q = _searchCtrl.text.trim();
      switch (_selectedPlatform) {
        case 'youtube':
          res = await _api.searchYoutube(q);
          break;
        case 'reddit':
          res = await _api.searchReddit(q);
          break;
        case 'twitter':
          res = await _api.searchTweets(q);
          break;
        case 'pinterest':
          res = await _api.searchPinterest(q);
          break;
      }
      setState(() {
        _results = res is List ? res : (res is Map && res['items'] != null ? res['items'] : [res]);
        _loading = false;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _loadTrending() async {
    setState(() { _loading = true; _error = null; });
    try {
      dynamic res;
      switch (_selectedPlatform) {
        case 'youtube':
          res = await _api.getYoutubeTrending();
          break;
        case 'twitter':
          res = await _api.getTwitterTrends();
          break;
        case 'pinterest':
          res = await _api.getPinterestTrending();
          break;
        default:
          res = await _api.getDashboardTrending();
      }
      setState(() {
        _results = res is List ? res : [res];
        _loading = false;
        _searched = true;
      });
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search & Explore')),
      body: Column(
        children: [
          _buildPlatformSelector(),
          _buildSearchBar(),
          Expanded(child: _buildResults()),
        ],
      ),
    );
  }

  Widget _buildPlatformSelector() {
    return SizedBox(
      height: 56,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        scrollDirection: Axis.horizontal,
        children: _platforms.map((p) {
          final selected = _selectedPlatform == p['key'];
          final color = AppTheme.platformColors[p['key']] ?? AppTheme.primary;
          return GestureDetector(
            onTap: () => setState(() {
              _selectedPlatform = p['key'];
              _results = [];
              _searched = false;
            }),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 10),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: selected ? color : color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: color.withOpacity(selected ? 1 : 0.3)),
              ),
              child: Row(
                children: [
                  Icon(p['icon'] as IconData,
                      color: selected ? Colors.white : color, size: 16),
                  const SizedBox(width: 6),
                  Text(p['label'] as String,
                      style: TextStyle(
                          color: selected ? Colors.white : color,
                          fontWeight: FontWeight.w600,
                          fontSize: 13)),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchCtrl,
              onSubmitted: (_) => _search(),
              decoration: InputDecoration(
                hintText: 'Search on ${_selectedPlatform}...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() { _results = []; _searched = false; });
                        })
                    : null,
              ),
            ),
          ),
          const SizedBox(width: 10),
          ElevatedButton(
            onPressed: _loading ? null : _search,
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(56, 56),
              padding: EdgeInsets.zero,
            ),
            child: const Icon(Icons.search),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.trending_up, color: AppTheme.secondary),
            tooltip: 'Trending pahije',
            onPressed: _loading ? null : _loadTrending,
          ),
        ],
      ),
    );
  }

  Widget _buildResults() {
    if (_loading) return const AppLoadingWidget(message: 'Search chalu ahe...');
    if (_error != null) return AppErrorWidget(message: _error!, onRetry: _search);
    if (!_searched) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search, size: 64, color: Colors.white24),
            const SizedBox(height: 16),
            const Text('Search kara ya Trending pahija', style: TextStyle(color: Colors.white38)),
          ],
        ),
      );
    }
    if (_results.isEmpty) {
      return const Center(
        child: Text('Kahi results nahi milale', style: TextStyle(color: Colors.white38)),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: _results.length,
      itemBuilder: (ctx, i) {
        final item = _results[i];
        if (item is Map) return PostCard(post: item, platform: _selectedPlatform);
        return ListTile(title: Text('$item'));
      },
    );
  }
}
