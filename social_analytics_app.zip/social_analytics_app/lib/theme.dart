import 'package:flutter/material.dart';

class AppTheme {
  static const Color primary = Color(0xFF6C63FF);
  static const Color secondary = Color(0xFF00D4AA);
  static const Color danger = Color(0xFFFF4757);
  static const Color warning = Color(0xFFFFD93D);
  static const Color dark = Color(0xFF0F0E17);
  static const Color card = Color(0xFF1A1A2E);
  static const Color surface = Color(0xFF16213E);

  static const Map<String, Color> platformColors = {
    'youtube': Color(0xFFFF0000),
    'reddit': Color(0xFFFF4500),
    'instagram': Color(0xFFE1306C),
    'twitter': Color(0xFF1DA1F2),
    'pinterest': Color(0xFFE60023),
  };

  static const Map<String, IconData> platformIcons = {
    'youtube': Icons.play_circle_fill,
    'reddit': Icons.reddit,
    'instagram': Icons.camera_alt,
    'twitter': Icons.tag,
    'pinterest': Icons.push_pin,
  };

  static ThemeData get darkTheme => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.dark(
          primary: primary,
          secondary: secondary,
          surface: surface,
          error: danger,
        ),
        scaffoldBackgroundColor: dark,
        appBarTheme: const AppBarTheme(
          backgroundColor: dark,
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        cardTheme: CardTheme(
          color: card,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          hintStyle: TextStyle(color: Colors.white38),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          ),
        ),
      );
}
