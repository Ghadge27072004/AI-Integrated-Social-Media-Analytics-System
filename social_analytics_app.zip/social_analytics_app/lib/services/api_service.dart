import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // ⚡ REAL ANDROID PHONE SATHI — tumchya PC cha IP ghala
  // PC var cmd/terminal madhe: ipconfig (Windows) ya ifconfig (Mac/Linux)
  // Example: http://10.55.66.26:8000
  static const String baseUrl = 'http://10.55.66.26:8000';

  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  final http.Client _client = http.Client();

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  Future<dynamic> _get(String path,
      {Map<String, String>? queryParams}) async {
    try {
      final uri = Uri.parse('$baseUrl$path')
          .replace(queryParameters: queryParams);
      final res = await _client.get(uri, headers: _headers);
      if (res.statusCode == 200) return jsonDecode(res.body);
      throw ApiException(res.statusCode, res.body);
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException(0, e.toString());
    }
  }

  Future<dynamic> _post(String path, Map<String, dynamic> body) async {
    try {
      final uri = Uri.parse('$baseUrl$path');
      final res = await _client.post(uri,
          headers: _headers, body: jsonEncode(body));
      if (res.statusCode == 200) return jsonDecode(res.body);
      throw ApiException(res.statusCode, res.body);
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException(0, e.toString());
    }
  }

  // ─── Health ──────────────────────────────────────────
  Future<Map> healthCheck() async => await _get('/health');

  // ─── Dashboard ───────────────────────────────────────
  Future<Map> getDashboardSummary() async =>
      await _get('/api/dashboard/summary');

  Future<List> getDashboardTrending({int limit = 10}) async {
    final res = await _get('/api/dashboard/trending',
        queryParams: {'limit': limit.toString()});
    return res is List ? res : [res];
  }

  Future<Map> getPlatformStats(String platform) async =>
      await _get('/api/dashboard/platform/$platform');

  Future<List> getRecentPosts({int limit = 20, String? platform}) async {
    final params = <String, String>{'limit': limit.toString()};
    if (platform != null) params['platform'] = platform;
    final res = await _get('/api/dashboard/recent-posts', queryParams: params);
    return res is List ? res : [res];
  }

  // ─── YouTube ─────────────────────────────────────────
  Future<dynamic> searchYoutube(String query, {int maxResults = 10}) async =>
      await _get('/api/youtube/search',
          queryParams: {'query': query, 'max_results': maxResults.toString()});

  Future<dynamic> getYoutubeTrending({String region = 'IN'}) async =>
      await _get('/api/youtube/trending', queryParams: {'region': region});

  Future<dynamic> getVideoStats(String videoId) async =>
      await _get('/api/youtube/stats/$videoId');

  // ─── Reddit ──────────────────────────────────────────
  Future<dynamic> getRedditPosts(
      {String subreddit = 'india', int limit = 20, String sort = 'hot'}) async =>
      await _get('/api/reddit/posts', queryParams: {
        'subreddit': subreddit,
        'limit': limit.toString(),
        'sort': sort,
      });

  Future<dynamic> getRedditComments(String postId, {int limit = 20}) async =>
      await _get('/api/reddit/comments/$postId',
          queryParams: {'limit': limit.toString()});

  Future<dynamic> searchReddit(String query, {int limit = 20}) async =>
      await _get('/api/reddit/search',
          queryParams: {'query': query, 'limit': limit.toString()});

  // ─── Instagram ───────────────────────────────────────
  Future<dynamic> getInstagramProfile(String username) async =>
      await _get('/api/instagram/profile', queryParams: {'username': username});

  Future<dynamic> getInstagramInsights(String username) async =>
      await _get('/api/instagram/insights', queryParams: {'username': username});

  // ─── Twitter ─────────────────────────────────────────
  Future<dynamic> searchTweets(String query, {int limit = 20}) async =>
      await _get('/api/twitter/search',
          queryParams: {'query': query, 'limit': limit.toString()});

  Future<dynamic> getTwitterTrends({String region = 'India'}) async =>
      await _get('/api/twitter/trends', queryParams: {'region': region});

  // ─── Pinterest ───────────────────────────────────────
  Future<dynamic> searchPinterest(String query) async =>
      await _get('/api/pinterest/search', queryParams: {'query': query});

  Future<dynamic> getPinterestTrending() async =>
      await _get('/api/pinterest/trending');

  // ─── AI Chatbot ──────────────────────────────────────
  Future<Map> chat(String message,
      {String sessionId = 'default', String platform = 'general'}) async =>
      await _post('/api/chatbot/chat', {
        'message': message,
        'session_id': sessionId,
        'platform': platform,
      });

  Future<dynamic> getChatSession(String sessionId) async =>
      await _get('/api/chatbot/session/$sessionId');

  Future<dynamic> clearChatSession(String sessionId) async {
    final uri = Uri.parse('$baseUrl/api/chatbot/session/$sessionId');
    final res = await _client.delete(uri, headers: _headers);
    return jsonDecode(res.body);
  }

  // ─── Crisis Alert ────────────────────────────────────
  Future<Map> analyzeCrisis(String text) async =>
      await _post('/api/crisis/analyze', {'text': text});

  Future<dynamic> scanBatch(List<String> posts, {int thresholdLevel = 1}) async =>
      await _post('/api/crisis/scan-batch', {
        'posts': posts,
        'threshold_level': thresholdLevel,
      });

  Future<List> getCrisisHistory({int limit = 20}) async {
    final res = await _get('/api/crisis/history',
        queryParams: {'limit': limit.toString()});
    return res is List ? res : [res];
  }

  // ─── AI Sentiment ────────────────────────────────────
  Future<Map> analyzeSentiment(String text) async =>
      await _post('/api/ai/sentiment', {'text': text});

  Future<dynamic> analyzeBatch(List<String> texts) async =>
      await _post('/api/ai/batch-sentiment', {'texts': texts});

  Future<Map> detectViralPotential(String title,
      {String description = ''}) async =>
      await _post('/api/ai/viral-potential',
          {'title': title, 'description': description});

  // ─── CrewAI ──────────────────────────────────────────
  Future<Map> runCrewPipeline(String text,
      {String platform = 'instagram', String? keyword}) async =>
      await _post('/api/crew/run', {
        'text': text,
        'platform': platform,
        if (keyword != null) 'keyword': keyword,
      });

  Future<List> listCrewAgents() async {
    final res = await _get('/api/crew/agents');
    return res is List ? res : [res];
  }

  // ─── Realtime ─────────────────────────────────────────
  Future<Map> getSnapshot() async => await _get('/api/realtime/snapshot');
}

class ApiException implements Exception {
  final int statusCode;
  final String message;
  ApiException(this.statusCode, this.message);

  @override
  String toString() =>
      statusCode == 0 ? 'Network Error: $message' : 'Error $statusCode: $message';
}
