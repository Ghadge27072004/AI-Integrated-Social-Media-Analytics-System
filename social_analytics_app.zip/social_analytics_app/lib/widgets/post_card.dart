import 'package:flutter/material.dart';
import '../theme.dart';

class PostCard extends StatelessWidget {
  final Map post;
  final String? platform;

  const PostCard({super.key, required this.post, this.platform});

  @override
  Widget build(BuildContext context) {
    final p = platform ?? post['platform'] ?? post['source'] ?? 'general';
    final color = AppTheme.platformColors[p.toString().toLowerCase()] ?? AppTheme.primary;
    final icon = AppTheme.platformIcons[p.toString().toLowerCase()] ?? Icons.public;

    final title = post['title'] ?? post['text'] ?? post['content'] ?? post['name'] ?? '';
    final author = post['author'] ?? post['username'] ?? post['channel'] ?? '';
    final score = post['score'] ?? post['likes'] ?? post['views'] ?? post['engagement'] ?? '';
    final sentiment = post['sentiment'] ?? post['sentiment_score'];
    final isViral = post['is_viral'] == true || post['viral'] == true;

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icon, color: color, size: 12),
                      const SizedBox(width: 4),
                      Text(
                        p.toString().toUpperCase(),
                        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                if (isViral) ...[
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.warning.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('🔥 VIRAL',
                        style: TextStyle(color: AppTheme.warning, fontSize: 10)),
                  ),
                ],
                const Spacer(),
                if (score != '') ...[
                  Icon(Icons.bar_chart, color: Colors.white38, size: 14),
                  const SizedBox(width: 4),
                  Text('$score', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '$title',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            if (author != '') ...[
              const SizedBox(height: 4),
              Text('@$author', style: const TextStyle(color: Colors.white38, fontSize: 12)),
            ],
            if (sentiment != null) ...[
              const SizedBox(height: 8),
              _buildSentimentBar(sentiment),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSentimentBar(dynamic sentiment) {
    double score = 0.0;
    String label = '';

    if (sentiment is Map) {
      score = (sentiment['score'] ?? 0.0).toDouble();
      label = sentiment['label'] ?? '';
    } else if (sentiment is num) {
      score = sentiment.toDouble();
      label = score > 0.2 ? 'Positive' : score < -0.2 ? 'Negative' : 'Neutral';
    } else {
      label = sentiment.toString();
    }

    final color = label.toLowerCase().contains('positive')
        ? AppTheme.secondary
        : label.toLowerCase().contains('negative')
            ? AppTheme.danger
            : Colors.orange;

    return Row(
      children: [
        Icon(Icons.sentiment_satisfied, color: color, size: 14),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(color: color, fontSize: 11)),
        if (score != 0.0) ...[
          const SizedBox(width: 4),
          Text('(${score.toStringAsFixed(2)})',
              style: const TextStyle(color: Colors.white38, fontSize: 11)),
        ],
      ],
    );
  }
}
